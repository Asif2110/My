package in.co.clg.mgt.sys.ctl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import in.co.clg.mgt.sys.bean.BaseBean;
import in.co.clg.mgt.sys.bean.StudentBean;
import in.co.clg.mgt.sys.exception.ApplicationException;
import in.co.clg.mgt.sys.exception.DuplicateRecordException;
import in.co.clg.mgt.sys.model.StudentModel;
import in.co.clg.mgt.sys.util.DataUtility;
import in.co.clg.mgt.sys.util.DataValidator;
import in.co.clg.mgt.sys.util.PropertyReader;
import in.co.clg.mgt.sys.util.ServletUtility;



/**
 * Servlet implementation class MyProfileCtl
 */

/**
 * MyProfile functionality Controller. Performs operation for Add, update
 * operations of MyProfile
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 */
@WebServlet(name = "StudentMyProfileCtl", urlPatterns = { "/ctl/studentMyProfile" })
public class StudentMyProfileCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	public static final String OP_CHANGE_MY_PROFILE = "Change My Profile";
	public static final String OP_CHANGE_MY_PASSWORD = "ChangePassword";

	private static Logger log = Logger.getLogger(StudentMyProfileCtl.class);

	/**
	 * Validate input Data Entered By Student
	 * 
	 * @param request
	 * @return
	 */
	@Override
	protected boolean validate(HttpServletRequest request) {
		log.debug("MyProfileCtl Method validate Started");

		boolean pass = true;

		String op = DataUtility.getString(request.getParameter("operation"));

		if (OP_CHANGE_MY_PASSWORD.equalsIgnoreCase(op) || op == null) {
			return pass;
		}

		if (DataValidator.isNull(request.getParameter("name"))) {
            request.setAttribute("name",
                    PropertyReader.getValue("error.require", "Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("userName"))) {
            request.setAttribute("userName",
                    PropertyReader.getValue("error.require", "User Name"));
            pass = false;
        }
        
     
        if (DataValidator.isNull(request.getParameter("email"))) {
            request.setAttribute("email",
                    PropertyReader.getValue("error.require", "email"));
            pass = false;
        }

        if (DataValidator.isNull(request.getParameter("contactNo"))) {
            request.setAttribute("contactNo",
                    PropertyReader.getValue("error.require", "Contact No"));
            pass = false;
        }
        if ("-----Select-----".equalsIgnoreCase(request.getParameter("gender"))) {
            request.setAttribute("gender",
                    PropertyReader.getValue("error.require", "Gender"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("dob"))) {
            request.setAttribute("dob",
                    PropertyReader.getValue("error.require", "Date of Birth"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("fatherName"))) {
            request.setAttribute("fatherName",
                    PropertyReader.getValue("error.require", "Father Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("fatherNo"))) {
            request.setAttribute("fatherNo",
                    PropertyReader.getValue("error.require", "Father Phone No"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("motherNo"))) {
            request.setAttribute("motherNo",
                    PropertyReader.getValue("error.require", "Mother Phone No"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("motherName"))) {
            request.setAttribute("motherName",
                    PropertyReader.getValue("error.require", "Mother Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("address"))) {
            request.setAttribute("address",
                    PropertyReader.getValue("error.require", "Address"));
            pass = false;
        }
        
		log.debug("MyProfileCtl Method validate Ended");
		return pass;
	}

	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("MyProfileCtl Method PopulateBean Started ");
		StudentBean bean = new StudentBean();

		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setName(DataUtility.getString(request.getParameter("name")));
		bean.setUserName(DataUtility.getString(request.getParameter("userName")));
		bean.setEmail(DataUtility.getString(request.getParameter("email")));
		bean.setContactNo(DataUtility.getString(request.getParameter("contactNo")));
		bean.setGender(DataUtility.getString(request.getParameter("gender")));
		bean.setFatherName(DataUtility.getString(request.getParameter("fatherName")));
		bean.setMotherName(DataUtility.getString(request.getParameter("motherName")));
		bean.setAddress(DataUtility.getString(request.getParameter("address")));
		bean.setFatherPhoneNo(DataUtility.getString(request.getParameter("fatherNo")));
		bean.setMotherPhoneNo(DataUtility.getString(request.getParameter("motherNo")));
		bean.setDob(DataUtility.getDate(request.getParameter("dob")));

		populateDTO(bean, request);

		log.debug("MyProfileCtl Method PopulateBean End ");
		return bean;
	}

	/**
	 * Display Concept for viewing profile page view
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		log.debug("MyProfileCTl Method doGet Started");

		HttpSession session = request.getSession(true);

		StudentBean StudentBean = (StudentBean) session.getAttribute("student");

		long id = StudentBean.getId();

		String op = DataUtility.getString(request.getParameter("operation"));
		// get Model

		StudentModel model = new StudentModel();

		if (id > 0 || op != null) {
			System.out.println("in id>0 condition");
			StudentBean bean;
			try {
				bean = model.findByPK(id);
				ServletUtility.setBean(bean, request);

			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			}
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("MyProfileCtl Method doGet Ended");
	}

	/**
	 * Submit Concept
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		log.debug("MyprofileCtl Method doPost Started");

		HttpSession session = request.getSession(true);

		StudentBean studentBean = (StudentBean) session.getAttribute("student");

		long id = studentBean.getId();

		String op = DataUtility.getString(request.getParameter("operation"));
		// get model
		StudentModel model = new StudentModel();

		if (OP_SAVE.equalsIgnoreCase(op)) {
			StudentBean bean = (StudentBean) populateBean(request);
			try {
				if (id > 0) {
					studentBean.setName(bean.getName());
					studentBean.setUserName(bean.getUserName());
					studentBean.setEmail(bean.getEmail());
					studentBean.setContactNo(bean.getContactNo());
					studentBean.setGender(bean.getGender());
					studentBean.setFatherName(bean.getFatherName());
					studentBean.setMotherName(bean.getMotherName());
					studentBean.setAddress(bean.getAddress());
					studentBean.setFatherPhoneNo(bean.getFatherPhoneNo());
					studentBean.setMotherPhoneNo(bean.getMotherPhoneNo());
					studentBean.setDob(bean.getDob());
					model.update(studentBean);
					
					ServletUtility.setBean(bean, request);
					ServletUtility.setSuccessMessage("Profile has been updated Successfully. ", request);
				}

			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage("Login id already exists", request);
			}
		} else if (OP_CHANGE_MY_PASSWORD.equalsIgnoreCase(op)) {
			ServletUtility.redirect(CMSView.STUDENT_CHANGE_PASSWORD_CTL, request, response);
			return;
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("MyProfileCtl doPost method end");
	}

	/**
	 * Returns the VIEW page of this Controller
	 * 
	 * @return
	 */
	@Override
	protected String getView() {

		return CMSView.STUDENT_MY_PROFILE_VIEW;
	}

}
