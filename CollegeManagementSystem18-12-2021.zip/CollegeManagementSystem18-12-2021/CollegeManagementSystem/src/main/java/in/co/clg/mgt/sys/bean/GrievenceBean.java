package in.co.clg.mgt.sys.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class GrievenceBean extends BaseBean{

	
	private String studentUSN;
	private String category;
	private String reletedTo;
	private String description;
	
	
	@Override
	public String getKey() {
		return null;
	}

	@Override
	public String getValue() {
		return null;
	}

}
