package in.co.clg.mgt.sys.ctl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import in.co.clg.mgt.sys.bean.BaseBean;
import in.co.clg.mgt.sys.bean.GrievenceBean;
import in.co.clg.mgt.sys.exception.ApplicationException;
import in.co.clg.mgt.sys.exception.DuplicateRecordException;
import in.co.clg.mgt.sys.model.GrievenceModel;
import in.co.clg.mgt.sys.util.DataUtility;
import in.co.clg.mgt.sys.util.DataValidator;
import in.co.clg.mgt.sys.util.PropertyReader;
import in.co.clg.mgt.sys.util.ServletUtility;


/**
 * Servlet implementation class GrievenceCtl
 */
@WebServlet(name="GrievenceCtl",urlPatterns={"/ctl/grievence"})
public class GrievenceCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(GrievenceCtl.class);

	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("GrievenceCtl validate method start");
        boolean pass = true;

        if (DataValidator.isNull(request.getParameter("studentUSN"))) {
            request.setAttribute("studentUSN",
                    PropertyReader.getValue("error.require", "Student USN"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("category"))) {
            request.setAttribute("category",
                    PropertyReader.getValue("error.require", "Category"));
            pass = false;
        }
      
        
        if (DataValidator.isNull(request.getParameter("reletedto"))) {
            request.setAttribute("reletedto",
                    PropertyReader.getValue("error.require", "Releted To"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("description"))) {
            request.setAttribute("description",
                    PropertyReader.getValue("error.require", "Description"));
            pass = false;
        }



        log.debug("GrievenceCtl validate method end");
        return pass;
    }
	
	
	
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("GrievenceCtl populateBean method start");
		GrievenceBean bean=new GrievenceBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setStudentUSN(DataUtility.getString(request.getParameter("studentUSN")));
		bean.setCategory(DataUtility.getString(request.getParameter("category")));
		bean.setReletedTo(DataUtility.getString(request.getParameter("reletedto")));
		bean.setDescription(DataUtility.getString(request.getParameter("description")));
		populateDTO(bean, request);
		log.debug("GrievenceCtl populateBean method end");
		return bean;
	}
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("GrievenceCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
	        
	       GrievenceModel model = new GrievenceModel();
	        long id = DataUtility.getLong(request.getParameter("id"));
	        
	        ServletUtility.setOpration("Add", request);
	        if (id > 0 || op != null) {
	            System.out.println("in id > 0  condition");
	            GrievenceBean bean;
	            try {
	                bean = model.findByPK(id);
	                ServletUtility.setOpration("Edit", request);
	                ServletUtility.setBean(bean, request);
	            } catch (ApplicationException e) {
	                ServletUtility.handleException(e, request, response);
	                return;
	            }
	        }

	        ServletUtility.forward(getView(), request, response);
	        log.debug("GrievenceCtl doGet method end");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("GrievenceCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		GrievenceModel model=new GrievenceModel();
		long id=DataUtility.getLong(request.getParameter("id"));
	
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			GrievenceBean bean=(GrievenceBean)populateBean(request);
				try {
					
					if(id>0){
					model.update(bean);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
	                ServletUtility.setBean(bean, request);
					}else {
						long pk=model.add(bean);
						ServletUtility.setSuccessMessage("Data is successfully Saved", request);
						ServletUtility.forward(getView(), request, response);
					}
	              
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(CMSView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_DELETE.equalsIgnoreCase(op)) {
		GrievenceBean bean=	(GrievenceBean)populateBean(request);
		try {
			model.delete(bean);
			ServletUtility.redirect(CMSView.GRIEVENCE_CTL, request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
		}
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(CMSView.GRIEVENCE_LIST_CTL, request, response);
			return;
	}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(CMSView.GRIEVENCE_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("Grievence doPost method end");
	}
   
	@Override
	protected String getView() {
		return CMSView.GRIEVENCE_VIEW;
	}

}
