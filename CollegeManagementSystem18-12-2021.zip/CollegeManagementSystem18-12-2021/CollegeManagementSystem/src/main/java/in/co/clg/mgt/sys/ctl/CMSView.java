package in.co.clg.mgt.sys.ctl;

public interface CMSView {

	public String APP_CONTEXT = "/CollegeManagementSystem";

	public String PAGE_FOLDER = "/jsp";

	public String ERROR_VIEW = PAGE_FOLDER + "/Error.jsp";

	public String USER_VIEW = PAGE_FOLDER + "/UserView.jsp";
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserListView.jsp";
	public String USER_REGISTRATION_VIEW = PAGE_FOLDER + "/userRegistration.jsp";
	
	
	public String FACULTY_VIEW = PAGE_FOLDER + "/faculty.jsp";
	public String FACULTY_LIST_VIEW = PAGE_FOLDER + "/facultyList.jsp";
	
	public String STUDENT_VIEW = PAGE_FOLDER + "/student.jsp";
	public String STUDENT_LIST_VIEW = PAGE_FOLDER + "/studentList.jsp";
	
	public String ERESOURCES_VIEW = PAGE_FOLDER + "/eresources.jsp";
	public String ERESOURCES_LIST_VIEW = PAGE_FOLDER + "/eresourcesList.jsp";
	
	public String EQUESTION_VIEW = PAGE_FOLDER + "/equestion.jsp";
	public String EQUESTION_LIST_VIEW = PAGE_FOLDER + "/equestionList.jsp";
	
	public String GRIEVENCE_VIEW = PAGE_FOLDER + "/grievence.jsp";
	public String GRIEVENCE_LIST_VIEW = PAGE_FOLDER + "/grievenceList.jsp";
	
	public String FACULTY_GRIEVENCE_VIEW = PAGE_FOLDER + "/facultyGrievence.jsp";
	public String FACULTY_GRIEVENCE_LIST_VIEW = PAGE_FOLDER + "/facultyGrievenceList.jsp";
	
	public String ACHIEVEMENT_VIEW = PAGE_FOLDER + "/achievement.jsp";
	public String ACHIEVEMENT_LIST_VIEW = PAGE_FOLDER + "/achievementList.jsp";
	

	public String STUDENT_LOGIN_VIEW = PAGE_FOLDER + "/studentLogin.jsp";
	public String FACULTY_LOGIN_VIEW = PAGE_FOLDER + "/facultyLogin.jsp";
	
	public String WELCOME_VIEW = PAGE_FOLDER + "/welcome.jsp";
	
	public String STUDENT_CHANGE_PASSWORD_VIEW = PAGE_FOLDER + "/studentChangePassword.jsp";
	public String FACULTY_CHANGE_PASSWORD_VIEW = PAGE_FOLDER + "/facultyChangePassword.jsp";
	
	public String STUDENT_MY_PROFILE_VIEW = PAGE_FOLDER + "/studentMyProfile.jsp";
	public String FACULTY_MY_PROFILE_VIEW = PAGE_FOLDER + "/facultyMyProfile.jsp";
	
	public String STUDENT_FORGET_PASSWORD_VIEW = PAGE_FOLDER + "/studentForgetPassword.jsp";
	
	public String FACULTY_FORGET_PASSWORD_VIEW = PAGE_FOLDER + "/facultyForgetPassword.jsp";
	
	public String ERROR_CTL = "/ctl/ErrorCtl";

	public String USER_CTL = APP_CONTEXT + "/ctl/UserCtl";
	public String USER_LIST_CTL = APP_CONTEXT + "/ctl/UserListCtl";
	
	public String FACULTY_CTL = APP_CONTEXT + "/ctl/faculty";
	public String FACULTY_LIST_CTL = APP_CONTEXT + "/ctl/facultyList";
	
	public String STUDENT_CTL = APP_CONTEXT + "/ctl/student";
	public String STUDENT_LIST_CTL = APP_CONTEXT + "/ctl/studentList";
	
	public String GRIEVENCE_CTL = APP_CONTEXT + "/ctl/grievence";
	public String GRIEVENCE_LIST_CTL = APP_CONTEXT + "/ctl/grievenceList";
	
	public String FACULTY_GRIEVENCE_CTL = APP_CONTEXT + "/ctl/facultyGrievence";
	public String FACULTY_GRIEVENCE_LIST_CTL = APP_CONTEXT + "/ctl/facultyGrievenceList";
	
	public String ACHIEVEMENT_CTL = APP_CONTEXT + "/ctl/achievement";
	public String ACHIEVEMENT_LIST_CTL = APP_CONTEXT + "/ctl/achievementList";
	
	public String ERESOURCES_CTL = APP_CONTEXT + "/ctl/eresources";
	public String ERESOURCES_LIST_CTL = APP_CONTEXT + "/ctl/eresourcesList";
	
	public String EQUESTION_CTL = APP_CONTEXT + "/ctl/equestion";
	public String EQUESTION_LIST_CTL = APP_CONTEXT + "/ctl/equestionList";
	
	public String USER_REGISTRATION_CTL = APP_CONTEXT + "/registration";
	public String FACULTY_LOGIN_CTL = APP_CONTEXT + "/facultyLogin";
	public String STUDENT_LOGIN_CTL = APP_CONTEXT + "/studentLogin";
	public String WELCOME_CTL = APP_CONTEXT + "/welcome";
	public String LOGOUT_CTL = APP_CONTEXT + "/LoginCtl";
	
	public String FACULTY_CHANGE_PASSWORD_CTL = APP_CONTEXT + "/ctl/facultyChangePassword";
	
	public String STUDENT_CHANGE_PASSWORD_CTL = APP_CONTEXT + "/ctl/studentChangePassword";
	
	public String MY_PROFILE_CTL = APP_CONTEXT + "/ctl/myProfile";
	
	public String FACULTY_MY_PROFILE_CTL = APP_CONTEXT + "/ctl/facultyMyProfile";
	
	public String STUDENT_MY_PROFILE_CTL = APP_CONTEXT + "/ctl/studentMyProfile";
	
	public String FACULTY_FORGET_PASSWORD_CTL = APP_CONTEXT + "/facultyForgetPassword";
	
	public String STUDENT_FORGET_PASSWORD_CTL = APP_CONTEXT + "/studentForgetPassword";

}
