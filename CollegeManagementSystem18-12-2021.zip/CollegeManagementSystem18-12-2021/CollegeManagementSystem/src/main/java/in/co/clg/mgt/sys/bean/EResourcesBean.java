package in.co.clg.mgt.sys.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EResourcesBean extends BaseBean{
	
	private String subjectCode;
	private String subjectName;
	private String link;
	
	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return subjectName;
	}

}
