package in.co.clg.mgt.sys.bean;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FacultyBean extends BaseBean {

	private String name;
	private String userName;
	private String password;
	private String confirmPassword;
	private String email;
	private String contactNo;
	private String gender;
	private String fatherName;
	private String motherName;
	private String address;
	private long roleId;
	private String roleName;
	

	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return name;
	}

	
	
}
