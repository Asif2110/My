package in.co.clg.mgt.sys.ctl;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import in.co.clg.mgt.sys.bean.BaseBean;
import in.co.clg.mgt.sys.bean.StudentBean;
import in.co.clg.mgt.sys.exception.ApplicationException;
import in.co.clg.mgt.sys.exception.DuplicateRecordException;
import in.co.clg.mgt.sys.model.StudentModel;
import in.co.clg.mgt.sys.util.DataUtility;
import in.co.clg.mgt.sys.util.DataValidator;
import in.co.clg.mgt.sys.util.PropertyReader;
import in.co.clg.mgt.sys.util.ServletUtility;


/**
 * Servlet implementation class StudentCtl
 */
@WebServlet(name="StudentCtl",urlPatterns={"/ctl/student"})
public class StudentCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(StudentCtl.class);

	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("StudentCtl validate method start");
        boolean pass = true;

        if (DataValidator.isNull(request.getParameter("name"))) {
            request.setAttribute("name",
                    PropertyReader.getValue("error.require", "Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("userName"))) {
            request.setAttribute("userName",
                    PropertyReader.getValue("error.require", "User Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("password"))) {
            request.setAttribute("password",
                    PropertyReader.getValue("error.require", "Password"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("email"))) {
            request.setAttribute("email",
                    PropertyReader.getValue("error.require", "email"));
            pass = false;
        }

        if (DataValidator.isNull(request.getParameter("contactNo"))) {
            request.setAttribute("contactNo",
                    PropertyReader.getValue("error.require", "Contact No"));
            pass = false;
        }
        if ("-----Select-----".equalsIgnoreCase(request.getParameter("gender"))) {
            request.setAttribute("gender",
                    PropertyReader.getValue("error.require", "Gender"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("dob"))) {
            request.setAttribute("dob",
                    PropertyReader.getValue("error.require", "Date of Birth"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("fatherName"))) {
            request.setAttribute("fatherName",
                    PropertyReader.getValue("error.require", "Father Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("fatherNo"))) {
            request.setAttribute("fatherNo",
                    PropertyReader.getValue("error.require", "Father Phone No"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("motherNo"))) {
            request.setAttribute("motherNo",
                    PropertyReader.getValue("error.require", "Mother Phone No"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("motherName"))) {
            request.setAttribute("motherName",
                    PropertyReader.getValue("error.require", "Mother Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("address"))) {
            request.setAttribute("address",
                    PropertyReader.getValue("error.require", "Address"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("studentUSN"))) {
            request.setAttribute("studentUSN",
                    PropertyReader.getValue("error.require", "Student USN"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("semester"))) {
            request.setAttribute("semester",
                    PropertyReader.getValue("error.require", "Semester"));
            pass = false;
        }

        log.debug("StudentCtl validate method end");
        return pass;
    }
	
	
	
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("StudentCtl populateBean method start");
		StudentBean bean=new StudentBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setName(DataUtility.getString(request.getParameter("name")));
		bean.setStundetUSN(DataUtility.getString(request.getParameter("studentUSN")));
		bean.setUserName(DataUtility.getString(request.getParameter("userName")));
		bean.setSemester(DataUtility.getString(request.getParameter("semester")));
		bean.setPassword(DataUtility.getString(request.getParameter("password")));
		bean.setEmail(DataUtility.getString(request.getParameter("email")));
		bean.setContactNo(DataUtility.getString(request.getParameter("contactNo")));
		bean.setGender(DataUtility.getString(request.getParameter("gender")));
		bean.setFatherName(DataUtility.getString(request.getParameter("fatherName")));
		bean.setMotherName(DataUtility.getString(request.getParameter("motherName")));
		bean.setAddress(DataUtility.getString(request.getParameter("address")));
		bean.setFatherPhoneNo(DataUtility.getString(request.getParameter("fatherNo")));
		bean.setMotherPhoneNo(DataUtility.getString(request.getParameter("motherNo")));
		bean.setDob(DataUtility.getDate(request.getParameter("dob")));
		populateDTO(bean, request);
		log.debug("StudentCtl populateBean method end");
		return bean;
	}
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("StudentCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
	        
	       StudentModel model = new StudentModel();
	        long id = DataUtility.getLong(request.getParameter("id"));
	        
	        ServletUtility.setOpration("Add", request);
	        if (id > 0 || op != null) {
	            System.out.println("in id > 0  condition");
	            StudentBean bean;
	            try {
	                bean = model.findByPK(id);
	                ServletUtility.setOpration("Edit", request);
	                ServletUtility.setBean(bean, request);
	            } catch (ApplicationException e) {
	                ServletUtility.handleException(e, request, response);
	                return;
	            }
	        }

	        ServletUtility.forward(getView(), request, response);
	        log.debug("StudentCtl doGet method end");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("StudentCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		StudentModel model=new StudentModel();
		long id=DataUtility.getLong(request.getParameter("id"));
	
		
		
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			StudentBean bean=(StudentBean)populateBean(request);
				try {
					if(id>0){
						
					model.update(bean);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
	                ServletUtility.setBean(bean, request);

					}else {
						long pk=model.add(bean);
						ServletUtility.setSuccessMessage("Data is successfully Saved", request);
						ServletUtility.forward(getView(), request, response);
					}
	              
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(CMSView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_DELETE.equalsIgnoreCase(op)) {
		StudentBean bean=	(StudentBean)populateBean(request);
		try {
			model.delete(bean);
			ServletUtility.redirect(CMSView.STUDENT_CTL, request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
		}
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(CMSView.STUDENT_LIST_CTL, request, response);
			return;
	}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(CMSView.STUDENT_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("Student doPost method end");
	}
	
   
	@Override
	protected String getView() {
		return CMSView.STUDENT_VIEW;
	}

}
