package in.co.clg.mgt.sys.bean;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentBean extends BaseBean {

	private String name;
	private String userName;
	private String password;
	private String confirmPassword;
	private String email;
	private String contactNo;
	private String gender;
	private Date dob;
	private String fatherName;
	private String fatherPhoneNo;
	private String motherName;
	private String motherPhoneNo;
	private String address;
	private String stundetUSN;
	private String semester;
	

	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return name;
	}

	
	
}
