package in.co.clg.mgt.sys.bean;

/**
 * DropdownListBean Interface has Abstract Method 
 */

public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
