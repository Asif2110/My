package in.co.clg.mgt.sys.bean;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
public class AchievementBean extends BaseBean {
	
	private String category;
	private String certificateName;
	private String description;
	private String certificateLink;

	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return certificateName;
	}

}
