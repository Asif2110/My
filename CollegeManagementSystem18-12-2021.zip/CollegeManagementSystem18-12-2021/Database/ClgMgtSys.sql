/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.22 : Database - clg_mgt_sys
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`clg_mgt_sys` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `clg_mgt_sys`;

/*Table structure for table `achievement` */

DROP TABLE IF EXISTS `achievement`;

CREATE TABLE `achievement` (
  `Id` bigint NOT NULL,
  `Category` varchar(225) DEFAULT NULL,
  `certificateName` varchar(225) DEFAULT NULL,
  `description` varchar(1500) DEFAULT NULL,
  `certificateLink` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `achievement` */

insert  into `achievement`(`Id`,`Category`,`certificateName`,`description`,`certificateLink`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Minus eligendi sunt','Ray Morrison','Rerum ipsum iure pa','fhhhhhhyy','root','root','2021-12-17 11:42:42','2021-12-18 13:01:41');

/*Table structure for table `equestion` */

DROP TABLE IF EXISTS `equestion`;

CREATE TABLE `equestion` (
  `ID` bigint NOT NULL,
  `SubjectCode` varchar(225) DEFAULT NULL,
  `Subjectname` varchar(225) DEFAULT NULL,
  `Link` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `equestion` */

insert  into `equestion`(`ID`,`SubjectCode`,`Subjectname`,`Link`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Error est culpa id','Driscoll Sweeneyj','Ipsa voluptatem dol','root','root','2021-12-16 17:16:39','2021-12-18 12:59:34');

/*Table structure for table `eresources` */

DROP TABLE IF EXISTS `eresources`;

CREATE TABLE `eresources` (
  `Id` bigint NOT NULL,
  `SubjectCode` varchar(225) DEFAULT NULL,
  `SubjectName` varchar(225) DEFAULT NULL,
  `Link` varchar(225) DEFAULT NULL,
  `Created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `eresources` */

insert  into `eresources`(`Id`,`SubjectCode`,`SubjectName`,`Link`,`Created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Iusto dolor eligendi','Orli Medinahh','Aut velit cupiditate','root','root','2021-12-15 11:26:07','2021-12-18 12:59:11');

/*Table structure for table `faculty` */

DROP TABLE IF EXISTS `faculty`;

CREATE TABLE `faculty` (
  `ID` bigint NOT NULL,
  `Name` varchar(225) DEFAULT NULL,
  `username` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `gender` varchar(225) DEFAULT NULL,
  `fatherName` varchar(225) DEFAULT NULL,
  `motherName` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `roleId` bigint DEFAULT NULL,
  `roleName` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `faculty` */

insert  into `faculty`(`ID`,`Name`,`username`,`password`,`email`,`contactNo`,`gender`,`fatherName`,`motherName`,`address`,`roleId`,`roleName`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Hari','Hari123','123','Hari@fmail.com','9685456586','Male','Hari','Manu','sdvsdvsdv',1,'HOD','root','root','2021-11-25 11:14:31','2021-11-25 11:14:34'),
(2,'pozazoboj','fozukon','Pa$$w0rd!','nixujugun','9685452536','Male','muzawes','xutydyj','Exercitationem corpo',2,'Faculty','root','root','2021-11-25 13:22:20','2021-12-18 12:53:43');

/*Table structure for table `facultygrievence` */

DROP TABLE IF EXISTS `facultygrievence`;

CREATE TABLE `facultygrievence` (
  `Id` bigint NOT NULL,
  `facultyId` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `category` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `relatedto` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `facultygrievence` */

insert  into `facultygrievence`(`Id`,`facultyId`,`category`,`relatedto`,`description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Ex repudiandae maxim','Brian Wise','Facere necessitatibu',NULL,'root','root','2021-12-16 16:54:24','2021-12-16 16:54:24');

/*Table structure for table `grievence` */

DROP TABLE IF EXISTS `grievence`;

CREATE TABLE `grievence` (
  `Id` bigint NOT NULL,
  `StudentUSN` varchar(225) DEFAULT NULL,
  `Category` varchar(225) DEFAULT NULL,
  `reletedto` varchar(225) DEFAULT NULL,
  `description` varchar(1500) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `grievence` */

insert  into `grievence`(`Id`,`StudentUSN`,`Category`,`reletedto`,`description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'123456','Nisi dolore est beat','dddf','Officiis veritatis e','root','root','2021-12-16 11:32:10','2021-12-18 13:00:20');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `Id` bigint NOT NULL,
  `Name` varchar(225) DEFAULT NULL,
  `userName` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `gender` varchar(225) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `fatherName` varchar(225) DEFAULT NULL,
  `fatherphoneNo` varchar(225) DEFAULT NULL,
  `motherName` varchar(225) DEFAULT NULL,
  `motherPhoneNo` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  `StudentUSN` varchar(225) DEFAULT NULL,
  `semester` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `student` */

insert  into `student`(`Id`,`Name`,`userName`,`password`,`email`,`contactNo`,`gender`,`dob`,`fatherName`,`fatherphoneNo`,`motherName`,`motherPhoneNo`,`address`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`,`StudentUSN`,`semester`) values 
(1,'Karyn Stanley','myvim','User@123','murygo@mailinator.com','7548689546','Male','1997-10-10','Thor Wynn','9542153585','Scarlett Bolton','7985456815','Eum id ipsa aspernavj','root','root','2021-12-17 11:25:36','2021-12-18 13:03:24','123456','8 sem');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
